=== WPPizza Gateway - MyCod ===
Contributors: ollybach
Plugin URI: http://www.wp-pizza.com
Author URI: http://www.wp-pizza.com
Tags: gateway, wppizza
Requires at least: PHP 5.3+, WP 3.3 , WPPizza 3.0+
Tested up to: 6.1
Stable tag: 1.0


WPPizza Gateway "MyCod" - A COD Type Gateway Example plugin for developing your own COD type WPPizza Gateway - Requires Wordpress 4.0+, WPPIZZA 3.0+, PHP 5.3+

== Description ==

WPPizza Gateway Development: A COD Type Gateway Example plugin for developing your own COD type WPPizza Gateway. Edit the file as required as per instructions, then activate the plugin and adjust settings in WPPizza -> Gateways - Requires WPPIZZA 3.0+

== Changelog ==

1.0  
* Initial Release  
13th January 2023  

